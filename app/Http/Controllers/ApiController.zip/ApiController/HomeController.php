<?php

namespace App\Http\Controllers\ApiController;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Validator;
use App\Http\Resources\Product;
use App\Models\Products;
use App\Models\Order;
use App\Models\User;
use App\Models\OrderDetail;
use App\Http\Resources\Order as Orders;
use App\Models\Banners;
use App\Http\Resources\Banner; 
use App\Models\Services;
use DateTime;
use CommonFunction;  
use App\Models\Bookings;
use App\Http\Resources\Booking;
use App\Models\Appointment; 
use App\Http\Resources\Appointment as Appointments; 
use App\Models\Availability;
use App\Http\Resources\Service; 
use App\Models\Category;
use App\Http\Resources\Categorys;  
use App\Models\Expert;
use App\Http\Resources\Expert as Experts;  
use App\Models\Feedback;
use App\Http\Resources\Feedback as Feedbacks; 
use DB;
use App\Models\Workshop;
use App\Http\Resources\Workshop as Workshops;  
use App\Models\Coupons;
use App\Http\Resources\Coupon; 
use App\Models\HealthTips;
use App\Http\Resources\HealthTip; 
use App\Http\Controllers\ApiController\BaseController as BaseController; 
use App\Models\Favourate;
use App\Http\Resources\Favourates;

class HomeController extends BaseController
{
    public function __construct() 
	{
        $this->User = new User;

        //header("Content-Type: application/json");
		$valid_passwords = array ("drolmaa" => "026866326a9d1d2b23226e4e5317569f");
		$valid_users = array_keys($valid_passwords);

		$user = request()->server('PHP_AUTH_USER');
		$pass = request()->server('PHP_AUTH_PW');

		$validated = (in_array($user, $valid_users)) && ($pass == $valid_passwords[$user]);

		if (!$validated) {
		  header('WWW-Authenticate: Basic realm="My Realm"');
		  header('HTTP/1.0 401 Unauthorized');
		  $re = array(
		  	"status" 	=> false,
		  	"message"	=> "You're not authorized to access."
		  );
		  echo json_encode($re, JSON_PRETTY_PRINT);
		  die;
		}
		
	}

    public function dashboard(Request $request,$user_id){ 
        try
		{ 

			$services = array();
			$banners = array();

			$healthTips = HealthTips::get(); //health tip data

			//category data
			$categorys = Category::Where(function($query) use ($request) { 
				if (isset($request['keyword']) && !empty($request['keyword'])) { 
					$query->where('category_name','LIKE', "%".$request['keyword']."%"); 
				}  
			})->get();

			$coupons = Coupons::get();//coupon data

			$products = Products::where(['is_featured'=>1,'status'=>config('constant.BLK_UNBLK.UNBLOCK')])->paginate(6);  //featured products data
            
			$users = $this->User->user_data($user_id, $user_data); //users data
			
            if($user_data->user_role->role_id == 3){
				//services data for customer
				$services = Services::where('services_for',3)->get(); 
				$services = Service::collection($services); 

				//banners data for customer
				$banners = Banners::get();
				$banners = Banner::collection($banners);
            }else if($user_data->user_role->role_id == 2){
				//services data for expert
				$services = Services::where('services_for',2)->get(); 
				$services = Service::collection($services);  
            }    
            
			//response
			$data['appointment_plans'] =  config('constant.PLAN');
			$data['all_status'] =  config('constant.STATUS');
			$data['banners'] =  $banners;
			$data['services'] =  $services;
			$data['categorys'] = Categorys::collection($categorys);
            $data['products'] = Product::collection($products);
			$data['coupons'] = Coupon::collection($coupons);
			$data['healthTips'] = HealthTip::collection($healthTips); 

            return $this->sendSuccess($data, 'Data listed successfully'); 
			 
		}
		catch (\Throwable $e)
    	{
    		return $this->sendFailed($e->getMessage().' on line '.$e->getLine(), 400);  
    	}
    }

	//services list
	public function services(Request $request){ 
        try
		{  
			$services = Services::where('services_for',3)
			->Where(function($query) use ($request) { 
				if (isset($request['keyword']) && !empty($request['keyword'])) { 
					$query->where('services_title','LIKE', "%".$request['keyword']."%");
					$query->orWhere('services_detail','LIKE', "%".$request['keyword']."%");
				}  
			})
			->get();  
            $data = Service::collection($services);  
            return $this->sendSuccess($data, 'Services listed successfully'); 
		}
		catch (\Throwable $e)
    	{
    		return $this->sendFailed($e->getMessage().' on line '.$e->getLine(), 400);  
    	}
    }

	//products list
	public function products(Request $request){ 
        try
		{   
			$products = Products::where(['status'=>config('constant.BLK_UNBLK.UNBLOCK')])
			->Where(function($query) use ($request) { 
				if (isset($request['keyword']) && !empty($request['keyword'])) { 
					$query->where('product_name','LIKE', "%".$request['keyword']."%");
					$query->orWhere('description','LIKE', "%".$request['keyword']."%");
					$query->orWhere('referenceses','LIKE', "%".$request['keyword']."%");
					$query->orWhere('instructions','LIKE', "%".$request['keyword']."%");
					$query->orWhere('quantity',$request['keyword']);
					$query->orWhere('selling_price',$request['keyword']);
					$query->orWhere('mrp',$request['keyword']);
				}  
				if (isset($request['category_id']) && !empty($request['category_id'])) { 
					$query->where('category_id',$request['category_id']); 
				}  
			})
			->get();  
            $data = Product::collection($products);  
            return $this->sendSuccess($data, 'Products listed successfully'); 
		}
		catch (\Throwable $e)
    	{
    		return $this->sendFailed($e->getMessage().' on line '.$e->getLine(), 400);  
    	}
    } 

	//products list
	public function product_detail(Request $request,$product_id){ 
        try
		{   
			$products = Products::where('product_id',$product_id)->first();
            $data = new Product($products);  
            return $this->sendSuccess($data, 'Product details get successfully'); 
		}
		catch (\Throwable $e)
    	{
    		return $this->sendFailed($e->getMessage().' on line '.$e->getLine(), 400);  
    	}
    } 
    
	//expert list
	public function expertList(Request $request){ 
        try
		{    
			$expert  = User::select('users.*')
			->Where(function($query) use ($request) {  
				if (isset($request['keyword']) && !empty($request['keyword'])) { 
					$query->where('full_name','LIKE', "%".$request['keyword']."%");
					$query->orWhere('mobile_number',$request['keyword']);
					$query->orWhere('email_address','LIKE', "%".$request['keyword']."%");
					$query->orWhere('address_details','LIKE', "%".$request['keyword']."%");
				}  
			}) 
			->join('user_role','user_role.user_id','=','users.user_id')
			->Where('user_role.role_id',2)
			->orderBy('users.user_id','desc')->get();  
            $data = Experts::collection($expert);  
			if(count($data)>0){
				return $this->sendSuccess($data, 'Expert listed successfully'); 
			}else{
				return $this->sendFailed('No record found', 200); 
			}
		}
		catch (\Throwable $e)
    	{
    		return $this->sendFailed($e->getMessage().' on line '.$e->getLine(), 400);  
    	}
    }

	//expert detail page
	public function expertDetail(Request $request,$id){ 
        try
		{     
			$availSlots = array();
			$reviews = array();
			$availability = array();
			$plansSpecial = array();
			
			$user_data = User::find($id);   

			if(!empty($user_data)){
				
				//feedback data
				$feedback    = Feedback::where('feedback_to',$id)->where('module_type','!=',config('constant.FEEDBACK.ORDER'))->get();
				$feedback_data    = Feedback::where('feedback_to',$id)->where('module_type',config('constant.FEEDBACK.ORDER'))->sum('rating');
				$rating = 0;
				if($feedback_data >0){
					$feedback_count = count($feedback);
					$rating = round($feedback_data/$feedback_count);       
				} 
				$reviews = Feedbacks::collection($feedback);  
 
				//personal data
				$specialPlans = explode(',',$user_data->special_plan); 
				if(count($specialPlans)>0){
					foreach($specialPlans as $plans){ 
						$plansSpecial[] = array_search($plans,config('constant.SPECIAL_PLANS'));
					} 
				}
				$infoPersonal = array( 'rating' => $rating , 'full_name' => $user_data->full_name, 'mobile_number' => $user_data->mobile_number,'email_address' => $user_data->email_address, 'user_age' => $user_data->user_age,'user_dob' => $user_data->user_dob, 'user_gender' => array_search($user_data->user_gender,config('constant.GENDER')),'country' => CommonFunction::GetSingleField('country','country_name','country_id',$user_data->country_id), 'state' => CommonFunction::GetSingleField('state','state_name','state_id',$user_data->state_id), 'city' => CommonFunction::GetSingleField('city','city_name','city_id',$user_data->city_id), 'address_details' => $user_data->address_details,'designation' => CommonFunction::GetSingleField('designation','designation_title','designation_id',$user_data->designation_id),'designation_id' => $user_data->designation_id, 'office_phone_number' => $user_data->office_phone_number,'user_experience' => $user_data->user_experience.' Years', 'licance_pic' => asset('public/expert_documents/'.$user_data->licance_pic), 'pan_card_pic' 	                => asset('public/expert_documents/'.$user_data->pan_card_pic), 'aadhar_card_pic' 	            => asset('public/expert_documents/'.$user_data->aadhar_card_pic), 'professional_certificate_pic' 	=> asset('public/expert_documents/'.$user_data->professional_certificate_pic), 'special_plan' => $plansSpecial, 'user_image' => asset('public/user_images/'.$user_data->user_image),);
				
				//availability data
				$avail_slots = Availability::where('user_id',$id)->get();
				if(count($avail_slots) >0){
					$begin = new DateTime( date('Y-m-d') );
					$end   = new DateTime(date('Y-m-d',strtotime('+14 days',strtotime(date('Y-m-d')))));
					for($i = $begin; $i <= $end; $i->modify('+1 day')){
						$avail = array();
						$date = $i->format("Y-m-d"); 
						$slots = Availability::where('date',$date)->get();
						$slotsAvail = CommonFunction::GetDateSlotCount('availability','date',$date,'user_id',$id,'status',config('constant.AVAIL_STATUS.AVAILABLE'));
						$slotsBook = CommonFunction::GetDateSlotCount('availability','date',$date,'user_id',$id,'status',config('constant.AVAIL_STATUS.BOOKED'));
						
						if(count($slots)>0){
							foreach($slots as $slotavailability){
								$avail[] = $slotavailability->time_slot;
							}
						}
						$availSlots[] = array('availability_id' =>$date,'date' =>date('d M, Y',strtotime($date)),'day' => date('l',strtotime($date)),'available_slots'=>  $slotsAvail,'booked_slots'=>  $slotsBook,'time_slot' =>  $avail,); 
					}
				} 
				
				//final data
				$data = array(
					'personal_details'=> $infoPersonal,
					'reviews' => $reviews,
					'availability' => $availSlots,
				);
				return $this->sendSuccess($data, 'Expert details get successfully'); 
			}else{
				return $this->sendFailed('No record found', 200); 
			}
		}
		catch (\Throwable $e)
    	{
    		return $this->sendFailed($e->getMessage().' on line '.$e->getLine(), 400);  
    	}
    }

	//my feedback list
	public function feedbackList(Request $request,$user_id)
    { 
		try
		{    
			$feedback  = Feedback::where('feedback_to',$user_id)->get();  
			if(count($feedback)>0){
				$data = Feedbacks::collection($feedback);  
				return $this->sendSuccess($data, 'Feedback listed successfully'); 
			}else{
				return $this->sendFailed('No record found', 200); 
			}
		}
		catch (\Throwable $e)
    	{
    		return $this->sendFailed($e->getMessage().' on line '.$e->getLine(), 400);  
    	}
    }

	//give feedback
	public function storeFeedback(Request $request)
	{ 
		$validator = Validator::make($request->all(),[
			'feedback_by'			=> 'required',
			'feedback_to'			=> 'required',
            'rating'				=> 'required',
            'message'		        => 'required',
            'module_type'			=> 'required',
			'module_id'				=> 'required'
		],[
			'feedback_by.required' 			=> 'User Id should be required',
			'feedback_to.required' 			=> 'Expert Id should be required',
			'rating.required' 				=> 'Ratting should be required',
            'message.required'      		=> 'Message should be required',
            'module_type.required'      	=> 'Module should be required',
            'module_id.required'      		=> 'Module Id be required',
		]);
 
        if($validator->fails()){
            return $this->sendFailed($validator->errors()->all(), 200);       
        }

		try
		{ 
			\DB::beginTransaction();
				$feedback = new Feedback;
				$feedback->fill($request->all())->save();
			\DB::commit();
			$record_data = new Feedbacks(Feedback::find($feedback->feedback_id));
			return $this->sendSuccess($record_data, 'Feedback sent successfully');
		}
		catch (\Throwable $e)
    	{
			\DB::rollback();
    		return $this->sendFailed($e->getMessage().' on line '.$e->getLine(), 400);  
    	}
	}

	//my wishlist
	public function wishlist(Request $request,$user_id)
    { 
		try
		{    
			$favourate = Favourate::where('user_id',$user_id)->get();  
			if(count($favourate)>0){
				$data = Favourates::collection($favourate);  
				return $this->sendSuccess($data, 'Feedback listed successfully'); 
			}else{
				return $this->sendFailed('No record found', 200); 
			}
		}
		catch (\Throwable $e)
    	{
    		return $this->sendFailed($e->getMessage().' on line '.$e->getLine(), 400);  
    	}
    }
  
	//delete multiple wishlist product
    public function deleteWishlist(Request $request)
    {  
        $ids = explode(',',$request['id']); 
        if(count($ids)>0){
            foreach($ids as $id){
                $delete=DB::table('favourate')->where('favourate_id',$id)->delete(); 
            }
    		if($delete){ 
    			return Response()->json([
                    "success" => true,
                    "message" =>'Wishlist product deleted successfully',
                ]); 
    		}else{
    			return Response()->json([
                    "success" => false,
                    "message" => 'Wishlist product not deleted successfully',
                ]);
    		} 
        }else{
			return Response()->json([
                "success" => false,
                "message" => 'Wishlist product not deleted successfully',
            ]);
		}
    }
	
	public function Payment(Request $request)
    {
        $validator = Validator::make($request->all(),[
			'razorpay_payment_id'   => 'required',
            'status'                => 'required',
            'module_id'          => 'required',
            'module_type'          => 'required',
        ],[
            'razorpay_payment_id.required'   => 'Razorpay id should be required',
            'status.required'                => 'Status be required',
            'module_id.required'            => 'Module id should be required',	  
            'module_type.required'          => 'Module type should be required',
		]); 

        if($validator->fails()){
            return $this->sendFailed($validator->errors()->all(), 200);       
        }

		try
		{ 
            if($request['status'] == 'success'){
				if($request['module_type'] == 'order'){
					$data = [
						'payment_status' => 'paid',
						'payment_id' => $request['razorpay_payment_id'],
						'payment_type' => config('constant.PAYMENT_MODE.ONLINE'),
					];
				}else{
					$data = [
						'payment_id' => $request['razorpay_payment_id'],
						'payment_mode' => config('constant.PAYMENT_MODE.ONLINE'),
					];
				}
                if($request['module_type'] == 'appointment'){
                    $updated = Appointment::where('appointment_id',$request['module_id'])->update($data);
                }
                else if($request['module_type'] == 'booking'){
					$updated = Bookings::where('booking_id',$request['module_id'])->update($data);
                }else if($request['module_type'] == 'order'){ 
					$updated = Order::where('order_id',$request['module_id'])->update($data);
                }
            }else{
                if($request['module_type'] == 'appointment'){
                    $updated = DB::table('appointment')->where('appointment_id',$request['module_id'])->delete();
                } else if($request['module_type'] == 'booking'){
					$updated = DB::table('bookings')->where('booking_id',$request['module_id'])->delete();
                }else if($request['module_type'] == 'order'){
					$updated = DB::table('order')->where('order_id',$request['module_id'])->delete();
                }
            }
            if(isset($updated) && !empty($updated)){
                if($request['module_type'] == 'appointment'){
                    $appoinment = Appointment::findOrfail($request['module_id']); 
                    $data = new Appointments($appoinment); 
                    $times = date('H',strtotime($data['time']));
                    Availability::where('user_id',$data['expert'])->where('time',$times)->update(['status'=>config('constant.AVAIL_STATUS.BOOKED')]);
                } else if($request['module_type'] == 'booking'){
					$booking = Bookings::findOrfail($request['module_id']); 
                    $data = new Booking($booking); 
                }else if($request['module_type'] == 'order'){  
					$order = Order::find($request['module_id']); 
                    $data = new Orders($order); 
                } 				
                return $this->sendSuccess(['record'=>$data,'module_type'=>$request['module_type']], 'Data Updated successfully'); 
            }else{
                return $this->sendFailed( 'Something went wrong',200); 
            } 
        }
        catch (\Throwable $e) 
        {
			return $this->sendFailed($e->getMessage(),400);
        } 
    }
 
	public function add_product_favourate(Request $request)
    { 
		$validator = Validator::make($request->all(),[
			'user_id'			=> 'required',
			'product_id'			=> 'required', 
		],[
			'user_id.required' 			=> 'User Id should be required',
			'product_id.required' 		=> 'Product Id should be required', 
		]);
 
        if($validator->fails()){
            return $this->sendFailed($validator->errors()->all(), 200);       
        }

		try
		{  
			$exist = Favourate::where(['user_id'=>$request['user_id'],'product_id'=>$request['product_id']])->first();
			
			if(!empty($exist)){
				$count_row = DB::table('favourate')->where(['user_id'=>$request['user_id'],'product_id'=>$request['product_id']])->delete(); 
				
				if(!empty($count_row)){  
					$favourate = Favourate::where('user_id',$request['user_id'])->get();   
					$favdata = Favourates::collection($favourate); 
					return $this->sendSuccess($favdata, 'Product removed from favourites successfully'); 
				}else{ 
					return $this->sendFailed('Something went wrong', 200);  
				}
			}else{
				\DB::beginTransaction(); 
					$favourate = new Favourate();
					$favourate->fill($request->all());  
					$favourate->save();   
				\DB::commit();   

				$favouratedata = Favourate::find($favourate->favourate_id);  
				$favdata = new Favourates($favouratedata);  

				return $this->sendSuccess($favdata,'Product added to favourites successfully'); 
			} 			
		}
		catch (\Throwable $e)
    	{
			\DB::rollback();
    		return $this->sendFailed($e->getMessage().' on line '.$e->getLine(), 400);  
    	}
    }


}
