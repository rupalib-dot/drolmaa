@include('include.header')
@include('include.nav')
<section id="contact-page-inner" id="contact-page-inner" role="contact"
    style="background-image:url({{asset('front_end/images/contactimg.png')}})">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <h2 class="hall-heading">Collaboration</h2>
            </div>
        </div>
    </div>
</section>
<section id="blog-inner">
    <div class="container">
        <div class="row">
            <img style="width: 100%;height: 100%;" src="{{asset('front_end/images/commingSoon.jpg')}}">
        </div>
    </div>
</section>
 
@include('include.footer')
@include('include.footer_bottom') 